/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kiemtra2;

/**
 *
 * @author H19
 */
public class SachThamKhao extends sach implements ISach{
    private boolean loai;

    public SachThamKhao(String ten, String nhaXB,boolean loai,double gia) {
        super(ten, nhaXB, gia);
        this.loai = loai;
    }
    

    public SachThamKhao(boolean loai) {
        this.loai = loai;
    }

    public boolean isLoai() {
        return loai;
    }

    public void setLoai(boolean loai) {
        this.loai = loai;
    }
    @Override
    public void setMa(){
        super.setMa();
        String[] tmp = getNhaXB().toUpperCase().split("\\s+");
        String res = "";
        for(String i:tmp){
            res += i.charAt(0);
        }
        super.setMa(res + super.getMa());
    }
    @Override
    public double getTien(){
        if(loai) return getGia()*1.1;
        else return getGia()*1.15;
    }
    @Override
    public String toString(){
        String s = "";
        if(loai) s = "co ban";
        else s = "ly thuyet";
        return getMa() + " " + getTen() + " " + getNhaXB() + " " + s + " " + (int)getTien();
    }
    
}
