/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kiemtra2;

/**
 *
 * @author H19
 */
public class SachGiaoKhoa extends sach implements ISach{
    private int lop,tap;
    private boolean baitap;

    public SachGiaoKhoa(String ten,String nhaXB,int lop, int tap,boolean baitap, double gia) {
        super(ten, nhaXB, gia);
        this.lop = lop;
        this.tap = tap;
        this.baitap = baitap;
    }

    public int getLop() {
        return lop;
    }

    public void setLop(int lop) {
        this.lop = lop;
    }

    public int getTap() {
        return tap;
    }

    public void setTap(int tap) {
        this.tap = tap;
    }

    public boolean isBaitap() {
        return baitap;
    }

    public void setBaitap(boolean baitap) {
        this.baitap = baitap;
    }
    @Override
    public void setMa(){
        super.setMa();
        super.setMa("SGK" + lop + tap +super.getMa());
    }
    public double getTien(){
        double sum=0;
        if(lop>=1 && lop<=5) sum = getGia()*0.9;
        if(lop>=6 && lop<=9) sum = getGia()*0.95;
        if(baitap) sum += getGia()*1.05;
        return sum;
    }
    public String toString(){
        String s = "";
        if(baitap) s = "bai tap";
        else s = "ly thuyet";
        return getMa() + " " + getTen() + " " + getNhaXB() + " " + lop + " " + tap +" " + s + " " + (int)getTien();
    }
}
