/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KiemTra1;
import java.util.Scanner;
/**
 *
 * @author H19
 */
public class XuLyXau {
    private String s;
    private Boolean gt;
    private int nam;
    public void input(){
        Scanner sc = new Scanner(System.in);
        s = sc.nextLine();
        gt = sc.nextBoolean();
        nam = sc.nextInt();
    }
    public void chuan_hoa(){
        String[] x = s.split("\\s+");
        for(String i :x){
            
        }
    }
}
