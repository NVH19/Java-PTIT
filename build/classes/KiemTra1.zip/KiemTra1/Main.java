/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KiemTra1;
import java.util.Scanner;
/**
 *
 * @author H19
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("1. Nhap 1 xau");
            System.out.println("2. Chuan hoa xau");
            System.out.println("3. In ra xau theo dinh dang");
            System.out.println("4. Nhap 1 day so nguyen");
            System.out.println("5. In so lon nhat, be nhat");
            System.out.println("6. In ra day so gi");
            System.out.println("7. Dua ra so lan xuat hien");
            System.out.println("8. Nhap vao 1 da thuc");
            System.out.println("9. Tinh gia tri dao ham tai x = 2");
        while(true){
            int select = sc.nextInt();
            switch (select) {
                case 0:
                    System.out.println("Finish");
                    System.exit(0);
                    break;
                case 
                    
                    break;
                default:
                    throw new AssertionError();
            }
        swic
        }
        
    }
}
