/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package KiemTra1;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import sun.security.util.Length;
/**
 *
 * @author H19
 */
public class DaySoNguyen {
    private ArrayList<Integer> a;
    public DaySoNguyen(){
        a = new ArrayList<>();
    }

    public DaySoNguyen(ArrayList<Integer> a) {
        this.a = a;
    }
    public void input(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap day so nguye");
        String s = sc.nextLine();
        String[] arr = s.split("\\s+");
        a.clear();
        for(String i: arr){
            a.add(Integer.parseInt(i));
        }
    }
    public void find_min_max(){
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for(int i: a){
            if(i>min) min = i;
            if(i>max) max = i;
        }
        System.out.println("Min = " + min + ", " + "Max = " + max);
    }
    public void check_day_so(){
        int ok=0;
        for(int i=0; i<a.; i++){
            
        }
    }
    
}
